# Daily Journal 2026–2027

Android tablet-first journal project.

## Included
- 2026 and 2027 date indexes
- Daily ruled journal canvas
- Stylus/touch handwriting canvas
- Pen thickness control
- Each stroke stores its own colour and tool
- Adjustable highlighter thickness/transparency
- Multiple highlighter colours
- Multiple pen colours
- Undo and clear
- Offline-first architecture
- 13-inch tablet-friendly Compose UI

## Next implementation step
Persistent local auto-save is included using Android SharedPreferences/JSON. Each completed stroke is saved immediately, and the page is restored when reopened. No network permission or internet connection is required.

## Build
Open this project in Android Studio with a compatible JDK and Android SDK, then build the debug APK:
`./gradlew assembleDebug`

The generated APK will normally be under:
`app/build/outputs/apk/debug/`
