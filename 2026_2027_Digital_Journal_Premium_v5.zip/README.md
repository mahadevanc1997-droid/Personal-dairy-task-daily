# Daily Journal 2026–2027 — Premium v5

Offline Android tablet journal for 2026 and 2027.

## Premium v5 improvements
- Dashboard home screen with quick actions
- Calendar navigation for 2026 and 2027
- Pen, Pencil, Marker, Highlighter and Eraser
- Multiple ink/highlighter colours
- Adjustable stroke size
- Undo history + undo last stroke
- Focus/full-screen writing mode
- Ruled, blank, dotted, grid and planner templates
- Favourite pages
- Mood, goal and gratitude/reflection fields
- Previous/next day navigation
- Light, dark and system appearance
- Offline JSON backup sharing
- Local autosave after changes
- Per-stroke colour/tool persistence
- Portrait and landscape friendly Compose layout

## Build without a computer
Use the included GitHub Actions workflow. Upload this ZIP to the repository and make sure the workflow file is in `.github/workflows/` and points to `2026_2027_Digital_Journal_Premium_v5.zip`.
