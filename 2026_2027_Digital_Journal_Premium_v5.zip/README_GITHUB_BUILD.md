# Build the Premium v5 APK with GitHub Actions

1. Put `2026_2027_Digital_Journal_Premium_v5.zip` in the root of your GitHub repository.
2. Put `.github/workflows/build-apk.yml` in the repository.
3. Commit/push.
4. Open **Actions → Build Daily Journal Premium APK**.
5. Wait for the green build.
6. Open the completed run and download **Daily-Journal-Premium-v5-APK** under Artifacts.
7. Extract the artifact and install `app-debug.apk` on the Android tablet.

No Android Studio or computer is required on your side; GitHub performs the build.
