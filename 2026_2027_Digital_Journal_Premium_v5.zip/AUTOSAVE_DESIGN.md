# Auto-save design

The app is designed to be offline-first. Each day's strokes should be stored
locally using Room (recommended) or a local file/JSON store. Save after each
completed stroke and when leaving a page. Load the day's strokes when opening
the date. No cloud account or internet connection is required.
