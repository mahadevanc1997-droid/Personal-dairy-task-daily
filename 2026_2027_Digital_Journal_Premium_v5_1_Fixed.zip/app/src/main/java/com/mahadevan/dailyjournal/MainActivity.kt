package com.mahadevan.dailyjournal

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.hypot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JournalApp() }
    }
}

enum class DrawingTool { PEN, PENCIL, MARKER, HIGHLIGHTER, ERASER }

enum class PageTemplate { RULED, BLANK, DOTS, GRID, PLANNER }

data class Stroke(
    val points: List<Offset>,
    val width: Float = 4f,
    val color: Color = Color.Black,
    val tool: DrawingTool = DrawingTool.PEN
)

data class DailyMeta(
    val favorite: Boolean = false,
    val mood: String = "",
    val goals: String = "",
    val gratitude: String = "",
    val typedNote: String = "",
    val template: PageTemplate = PageTemplate.RULED
)

private class JournalStorage(context: Context) {
    private val prefs = context.getSharedPreferences("journal_premium", Context.MODE_PRIVATE)

    fun saveStrokes(date: LocalDate, strokes: List<Stroke>) {
        val array = JSONArray()
        strokes.forEach { stroke ->
            val obj = JSONObject()
            obj.put("width", stroke.width.toDouble())
            obj.put("color", stroke.color.value.toLong())
            obj.put("tool", stroke.tool.name)
            val points = JSONArray()
            stroke.points.forEach { p ->
                points.put(JSONObject().apply {
                    put("x", p.x.toDouble())
                    put("y", p.y.toDouble())
                })
            }
            obj.put("points", points)
            array.put(obj)
        }
        prefs.edit().putString("strokes_${date}", array.toString()).apply()
    }

    fun loadStrokes(date: LocalDate): List<Stroke> {
        val raw = prefs.getString("strokes_${date}", null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val pointsJson = obj.getJSONArray("points")
                    val points = buildList {
                        for (j in 0 until pointsJson.length()) {
                            val p = pointsJson.getJSONObject(j)
                            add(Offset(p.getDouble("x").toFloat(), p.getDouble("y").toFloat()))
                        }
                    }
                    add(Stroke(
                        points,
                        obj.getDouble("width").toFloat(),
                        Color(obj.getLong("color").toULong()),
                        DrawingTool.valueOf(obj.getString("tool"))
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    fun saveMeta(date: LocalDate, meta: DailyMeta) {
        prefs.edit()
            .putBoolean("fav_${date}", meta.favorite)
            .putString("mood_${date}", meta.mood)
            .putString("goals_${date}", meta.goals)
            .putString("gratitude_${date}", meta.gratitude)
            .putString("typed_${date}", meta.typedNote)
            .putString("template_${date}", meta.template.name)
            .apply()
    }

    fun loadMeta(date: LocalDate): DailyMeta = DailyMeta(
        favorite = prefs.getBoolean("fav_${date}", false),
        mood = prefs.getString("mood_${date}", "") ?: "",
        goals = prefs.getString("goals_${date}", "") ?: "",
        gratitude = prefs.getString("gratitude_${date}", "") ?: "",
        typedNote = prefs.getString("typed_${date}", "") ?: "",
        template = runCatching { PageTemplate.valueOf(prefs.getString("template_${date}", PageTemplate.RULED.name)!!) }.getOrDefault(PageTemplate.RULED)
    )

    fun exportBackup(): String {
        val out = JSONObject()
        val all = JSONObject()
        prefs.all.forEach { (key, value) ->
            if (key.startsWith("strokes_") || key.startsWith("fav_") || key.startsWith("mood_") ||
                key.startsWith("goals_") || key.startsWith("gratitude_") || key.startsWith("typed_") || key.startsWith("template_")) {
                all.put(key, value)
            }
        }
        out.put("app", "Daily Journal 2026-2027 Premium")
        out.put("backup", all)
        return out.toString(2)
    }

    fun setTheme(theme: String) = prefs.edit().putString("theme", theme).apply()
    fun theme(): String = prefs.getString("theme", "SYSTEM") ?: "SYSTEM"
}

@Composable
fun JournalApp() {
    val context = LocalContext.current
    val storage = remember { JournalStorage(context) }
    var selectedDate by remember { mutableStateOf(LocalDate.of(2026, 1, 1)) }
    var screen by remember { mutableStateOf("home") }
    var theme by remember { mutableStateOf(storage.theme()) }

    val dark = when (theme) {
        "DARK" -> true
        "LIGHT" -> false
        else -> androidx.compose.foundation.isSystemInDarkTheme()
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        when (screen) {
            "home" -> HomeScreen(
                storage = storage,
                onDate = { selectedDate = it; screen = "day" },
                onCalendar = { screen = "calendar" },
                onSettings = { screen = "settings" }
            )
            "calendar" -> CalendarScreen(
                onBack = { screen = "home" },
                onDate = { selectedDate = it; screen = "day" }
            )
            "settings" -> SettingsScreen(
                storage = storage,
                currentTheme = theme,
                onTheme = { theme = it; storage.setTheme(it) },
                onBack = { screen = "home" }
            )
            else -> DailyPage(
                date = selectedDate,
                storage = storage,
                onBack = { screen = "home" },
                onDateChange = { selectedDate = it }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    storage: JournalStorage,
    onDate: (LocalDate) -> Unit,
    onCalendar: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val today = LocalDate.now().let { if (it.year in 2026..2027) it else LocalDate.of(2026, 1, 1) }
    var query by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var searchDate by remember { mutableStateOf<LocalDate?>(null) }

    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Daily Journal", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("2026 • 2027", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { showSearch = true }) { Text("⌕", fontSize = 28.sp) }
                IconButton(onClick = onSettings) { Text("⚙", fontSize = 23.sp) }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(22.dp)) {
                    Text("Good day 👋", fontSize = 17.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(today.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM")), fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { onDate(today) }, modifier = Modifier.fillMaxWidth()) { Text("✎  Write today") }
                }
            }
            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                DashboardCard("📅", "Calendar", "Jump to any date", onCalendar, Modifier.weight(1f))
                DashboardCard("⭐", "Favorites", "Saved pages", {
                    val d = findFavorite(storage)
                    onDate(d ?: today)
                }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                DashboardCard("📝", "Templates", "Planner & paper", { onDate(today) }, Modifier.weight(1f))
                DashboardCard("💾", "Backup", "Export journal data", {
                    shareText(context, "Daily Journal Backup", storage.exportBackup())
                }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(20.dp))
            Text("Quick access", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(2026, 2027).forEach { year ->
                    FilterChip(selected = false, onClick = { onDate(LocalDate.of(year, 1, 1)) }, label = { Text("$year") })
                }
                FilterChip(selected = false, onClick = { onCalendar() }, label = { Text("Browse dates") })
            }
            Spacer(Modifier.height(18.dp))
            Text("Premium-style tools are designed around quick stylus writing, clean tool access and offline storage.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (showSearch) {
        AlertDialog(
            onDismissRequest = { showSearch = false },
            title = { Text("Find a date") },
            text = {
                Column {
                    OutlinedTextField(query, { query = it }, label = { Text("YYYY-MM-DD") }, singleLine = true)
                    searchDate = runCatching { LocalDate.parse(query) }.getOrNull()
                    if (searchDate != null && searchDate!!.year in 2026..2027) Text("Date found ✓", color = MaterialTheme.colorScheme.primary)
                }
            },
            confirmButton = {
                Button(onClick = { searchDate?.let(onDate); showSearch = false }) { Text("Open") }
            },
            dismissButton = { TextButton(onClick = { showSearch = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun DashboardCard(icon: String, title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier) {
    Card(onClick = onClick, modifier = modifier.height(118.dp), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(icon, fontSize = 24.sp)
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun findFavorite(storage: JournalStorage): LocalDate? {
    var d = LocalDate.of(2026, 1, 1)
    repeat(730) {
        if (storage.loadMeta(d).favorite) return d
        d = d.plusDays(1)
    }
    return null
}

@Composable
private fun CalendarScreen(onBack: () -> Unit, onDate: (LocalDate) -> Unit) {
    var year by remember { mutableIntStateOf(2026) }
    Scaffold(topBar = {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Home") }
            Text("Calendar", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { year = if (year == 2026) 2027 else 2026 }) { Text("$year") }
        }
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(14.dp)) {
            (1..12).chunked(3).forEach { months ->
                Row(Modifier.fillMaxWidth()) {
                    months.forEach { month -> MonthCard(year, month, onDate, Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun MonthCard(year: Int, month: Int, onDate: (LocalDate) -> Unit, modifier: Modifier) {
    val first = LocalDate.of(year, month, 1)
    val days = first.lengthOfMonth()
    Card(modifier.padding(5.dp), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(9.dp)) {
            Text(first.format(DateTimeFormatter.ofPattern("MMM")), fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("M", "T", "W", "T", "F", "S", "S").forEach { Text(it, fontSize = 9.sp) }
            }
            val offset = first.dayOfWeek.value - 1
            for (week in 0..5) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (col in 0..6) {
                        val n = week * 7 + col - offset + 1
                        if (n in 1..days) TextButton(onClick = { onDate(LocalDate.of(year, month, n)) }, contentPadding = PaddingValues(0.dp)) { Text("$n", fontSize = 10.sp) }
                        else Spacer(Modifier.size(30.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyPage(date: LocalDate, storage: JournalStorage, onBack: () -> Unit, onDateChange: (LocalDate) -> Unit) {
    val initialMeta = remember(date) { storage.loadMeta(date) }
    val strokes = remember(date) { mutableStateListOf<Stroke>().apply { addAll(storage.loadStrokes(date)) } }
    var undoStack by remember(date) { mutableStateOf<List<List<Stroke>>>(emptyList()) }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var tool by remember { mutableStateOf(DrawingTool.PEN) }
    var color by remember { mutableStateOf(Color.Black) }
    var width by remember { mutableFloatStateOf(4f) }
    var meta by remember(date) { mutableStateOf(initialMeta) }
    var showOptions by remember { mutableStateOf(false) }
    var fullScreen by remember { mutableStateOf(false) }

    val penColors = listOf(Color.Black, Color(0xFF1565C0), Color(0xFFD32F2F), Color(0xFF2E7D32), Color(0xFF7B1FA2), Color(0xFFEF6C00), Color(0xFFC2185B), Color(0xFF6D4C41))
    val highlighterColors = listOf(Color(0xFFFFD600), Color(0xFF76FF03), Color(0xFF40C4FF), Color(0xFFFF80AB), Color(0xFFFFAB40), Color(0xFFE040FB))

    fun persist() { storage.saveStrokes(date, strokes); storage.saveMeta(date, meta) }
    fun pushUndo() { undoStack = undoStack + listOf(strokes.toList()) }

    Scaffold(
        topBar = if (fullScreen) ({}) else ({
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Home") }
                Column(Modifier.weight(1f)) {
                    Text(date.format(DateTimeFormatter.ofPattern("EEEE")), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(date.format(DateTimeFormatter.ofPattern("dd MMMM yyyy")), fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { meta = meta.copy(favorite = !meta.favorite); persist() }) { Text(if (meta.favorite) "★" else "☆", fontSize = 27.sp) }
                IconButton(onClick = { showOptions = true }) { Text("⋮", fontSize = 28.sp) }
            }
        })
    ) { pad ->
        Column(Modifier.padding(if (fullScreen) PaddingValues(0.dp) else pad).fillMaxSize()) {
            if (!fullScreen) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ToolChip("Pen", tool == DrawingTool.PEN) { tool = DrawingTool.PEN; width = 4f }
                    ToolChip("Pencil", tool == DrawingTool.PENCIL) { tool = DrawingTool.PENCIL; width = 3f }
                    ToolChip("Marker", tool == DrawingTool.MARKER) { tool = DrawingTool.MARKER; width = 8f }
                    ToolChip("Highlight", tool == DrawingTool.HIGHLIGHTER) { tool = DrawingTool.HIGHLIGHTER; width = 18f }
                    ToolChip("Eraser", tool == DrawingTool.ERASER) { tool = DrawingTool.ERASER }
                }
                if (tool != DrawingTool.ERASER) {
                    val palette = if (tool == DrawingTool.HIGHLIGHTER) highlighterColors else penColors
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        palette.forEach { c -> ColorDot(c, c == color) { color = c } }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 12.dp)) {
                        Text("Size", fontSize = 12.sp)
                        Slider(value = width, onValueChange = { width = it }, valueRange = if (tool == DrawingTool.HIGHLIGHTER) 10f..32f else 1f..14f, modifier = Modifier.weight(1f))
                        Text(width.toInt().toString(), fontSize = 12.sp)
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = {
                        if (undoStack.isNotEmpty()) {
                            val previous = undoStack.last()
                            undoStack = undoStack.dropLast(1)
                            strokes.clear(); strokes.addAll(previous); persist()
                        }
                    }) { Text("↶ Undo") }
                    TextButton(onClick = { if (strokes.isNotEmpty()) { pushUndo(); strokes.removeAt(strokes.lastIndex); persist() } }) { Text("Undo stroke") }
                    TextButton(onClick = { fullScreen = true }) { Text("⛶ Focus") }
                    TextButton(onClick = { showOptions = true }) { Text("More") }
                }
            }

            if (!fullScreen) {
                Text("“${quoteFor(date)}”", modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            DrawingSurface(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = if (fullScreen) 0.dp else 10.dp, vertical = 4.dp),
                strokes = strokes,
                current = current,
                color = color,
                width = width,
                tool = tool,
                template = meta.template,
                onCurrent = { current = it },
                onStroke = { points ->
                    if (points.isNotEmpty()) {
                        if (tool == DrawingTool.ERASER) {
                            pushUndo()
                            val hit = nearestStroke(strokes, points.first(), 34f)
                            if (hit >= 0) strokes.removeAt(hit)
                        } else {
                            pushUndo()
                            strokes.add(Stroke(points, width, color, tool))
                        }
                        persist()
                    }
                    current = emptyList()
                }
            )

            if (!fullScreen) {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(10.dp)) {
                    Text("Today", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        SmallField("Mood", meta.mood, { meta = meta.copy(mood = it); persist() }, Modifier.weight(1f))
                        SmallField("Goal", meta.goals, { meta = meta.copy(goals = it); persist() }, Modifier.weight(1f))
                    }
                    SmallField("Gratitude / reflection", meta.gratitude, { meta = meta.copy(gratitude = it); persist() }, Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { onDateChange(date.minusDays(1)) }) { Text("← Previous") }
                        TextButton(onClick = { onDateChange(date.plusDays(1)) }) { Text("Next →") }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { fullScreen = false }) { Text("Exit focus") }
                    TextButton(onClick = { meta = meta.copy(favorite = !meta.favorite); persist() }) { Text(if (meta.favorite) "★ Saved" else "☆ Save") }
                }
            }
        }
    }

    if (showOptions) {
        AlertDialog(
            onDismissRequest = { showOptions = false },
            title = { Text("Page options") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Paper template", fontWeight = FontWeight.Bold)
                    PageTemplate.values().forEach { t ->
                        FilterChip(selected = meta.template == t, onClick = { meta = meta.copy(template = t); persist(); showOptions = false }, label = { Text(t.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }) })
                    }
                    Text("Tip: two-finger double tap can be added later for faster undo/redo gestures.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { strokes.clear(); persist(); showOptions = false }) { Text("Clear page") } },
            dismissButton = { TextButton(onClick = { showOptions = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun ToolChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(if (selected) 34.dp else 28.dp).background(color, CircleShape).border(if (selected) 3.dp else 1.dp, MaterialTheme.colorScheme.outline, CircleShape).padding(2.dp)) {
        Surface(onClick = onClick, modifier = Modifier.fillMaxSize(), color = Color.Transparent, shape = CircleShape) {}
    }
}

@Composable
private fun SmallField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier) {
    OutlinedTextField(value, onValue, label = { Text(label) }, singleLine = true, modifier = modifier.padding(vertical = 3.dp))
}

@Composable
private fun DrawingSurface(
    modifier: Modifier,
    strokes: List<Stroke>,
    current: List<Offset>,
    color: Color,
    width: Float,
    tool: DrawingTool,
    template: PageTemplate,
    onCurrent: (List<Offset>) -> Unit,
    onStroke: (List<Offset>) -> Unit
) {
    Canvas(modifier.background(Color.White).border(1.dp, MaterialTheme.colorScheme.outlineVariant).pointerInput(tool, color, width) {
        var path = emptyList<Offset>()
        detectDragGestures(
            onDragStart = {
                path = listOf(it)
                onCurrent(path)
            },
            onDrag = { change, _ ->
                path = path + change.position
                onCurrent(path)
            },
            onDragEnd = { onStroke(path) },
            onDragCancel = { path = emptyList(); onCurrent(emptyList()) }
        )
    }) {
        drawTemplate(template)
        strokes.forEach { drawStroke(it) }
        if (current.isNotEmpty() && tool != DrawingTool.ERASER) drawStroke(Stroke(current, width, color, tool))
    }
}

private fun DrawScope.drawStroke(stroke: Stroke) {
    if (stroke.points.size == 1) {
        drawCircle(stroke.color.copy(alpha = if (stroke.tool == DrawingTool.HIGHLIGHTER) .38f else 1f), stroke.width / 2, stroke.points.first())
        return
    }
    val alpha = when (stroke.tool) { DrawingTool.HIGHLIGHTER -> .38f; DrawingTool.PENCIL -> .75f; else -> 1f }
    val effectiveWidth = when (stroke.tool) { DrawingTool.PENCIL -> stroke.width * .75f; DrawingTool.MARKER -> stroke.width * 1.4f; else -> stroke.width }
    stroke.points.zipWithNext().forEach { (a, b) ->
        drawLine(stroke.color.copy(alpha = alpha), a, b, effectiveWidth, if (stroke.tool == DrawingTool.HIGHLIGHTER) StrokeCap.Square else StrokeCap.Round)
    }
}

private fun DrawScope.drawTemplate(template: PageTemplate) {
    val line = Color(0xFFCBD5E1).copy(alpha = .75f)
    when (template) {
        PageTemplate.RULED -> { var y = 55.dp.toPx(); while (y < size.height) { drawLine(line, Offset(18.dp.toPx(), y), Offset(size.width - 18.dp.toPx(), y)); y += 38.dp.toPx() } }
        PageTemplate.GRID -> { var x = 0f; while (x < size.width) { drawLine(line, Offset(x, 0f), Offset(x, size.height)); x += 32.dp.toPx() }; var y = 0f; while (y < size.height) { drawLine(line, Offset(0f, y), Offset(size.width, y)); y += 32.dp.toPx() } }
        PageTemplate.DOTS -> { var x = 18.dp.toPx(); while (x < size.width) { var y = 18.dp.toPx(); while (y < size.height) { drawCircle(line, 1.2.dp.toPx(), Offset(x, y)); y += 28.dp.toPx() }; x += 28.dp.toPx() } }
        PageTemplate.PLANNER -> { drawLine(line, Offset(0f, 70.dp.toPx()), Offset(size.width, 70.dp.toPx()), 2.dp.toPx()); drawLine(line, Offset(size.width / 2, 70.dp.toPx()), Offset(size.width / 2, size.height)); }
        PageTemplate.BLANK -> Unit
    }
}

private fun nearestStroke(strokes: List<Stroke>, point: Offset, threshold: Float): Int {
    var best = -1
    var bestDistance = threshold
    strokes.forEachIndexed { index, stroke ->
        stroke.points.forEach { p ->
            val d = hypot((p.x - point.x).toDouble(), (p.y - point.y).toDouble()).toFloat()
            if (d < bestDistance) { bestDistance = d; best = index }
        }
    }
    return best
}

private fun quoteFor(date: LocalDate) = listOf(
    "Small steps every day lead to big results.", "Progress, not perfection.", "Make today meaningful.",
    "One day at a time.", "Stay focused. Stay positive.", "Every day is a fresh beginning."
)[date.dayOfYear % 6]

@Composable
private fun SettingsScreen(storage: JournalStorage, currentTheme: String, onTheme: (String) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    Scaffold(topBar = {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Home") }
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Appearance", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SYSTEM", "LIGHT", "DARK").forEach { t -> FilterChip(currentTheme == t, { onTheme(t) }, label = { Text(t.lowercase().replaceFirstChar { it.uppercase() }) }) }
            }
            HorizontalDivider()
            Text("Backup & privacy", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Button(onClick = { shareText(context, "Daily Journal Backup", storage.exportBackup()) }, modifier = Modifier.fillMaxWidth()) { Text("Export offline backup") }
            OutlinedButton(onClick = { shareText(context, "Daily Journal Info", "Daily Journal 2026–2027 Premium\nAll journal content is stored locally on this device.") }, modifier = Modifier.fillMaxWidth()) { Text("Share app information") }
            Text("No account or internet connection is required for writing. Your pages are saved locally after changes.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun shareText(context: Context, title: String, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text); putExtra(Intent.EXTRA_SUBJECT, title) }
    context.startActivity(Intent.createChooser(intent, title))
}
