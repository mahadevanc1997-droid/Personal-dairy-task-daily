# Daily Journal 2026–2027 — Tablet Build

This project is prepared for a **computer-free build using GitHub Actions**.

## What the app includes
- 2026 + 2027 daily journal
- 730 daily pages
- Jan–Jun and Jul–Dec index pages
- Date navigation
- Ruled handwriting area
- Stylus drawing
- Multiple pen colours
- Multiple highlighter colours
- Adjustable pen/highlighter thickness
- Undo and clear
- Automatic offline saving of completed strokes
- Handwriting restored after reopening a date
- Portrait and landscape support
- No internet required while using the journal

## Build on your Android tablet
1. Create/sign in to a GitHub account.
2. Create a new repository, preferably named `daily-journal-2026-2027`.
3. Upload the project files into the repository, including `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab.
5. Select **Build Daily Journal APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run.
9. Under **Artifacts**, download `Daily-Journal-APK`.
10. Extract the downloaded ZIP and install `app-debug.apk` on the tablet.

The APK is a debug build for personal use/testing. Android may ask you to allow installation from the browser/file manager.

## Important
This repository contains source code, not a precompiled APK. GitHub Actions performs the Android build in the cloud.
