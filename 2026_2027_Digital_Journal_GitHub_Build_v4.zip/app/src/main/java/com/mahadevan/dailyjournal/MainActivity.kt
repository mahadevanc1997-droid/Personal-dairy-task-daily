package com.mahadevan.dailyjournal

import android.os.Bundle
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JournalApp() }
    }
}

enum class DrawingTool { PEN, HIGHLIGHTER }

data class Stroke(
    val points: List<Offset>,
    val width: Float = 4f,
    val color: Color = Color.Black,
    val tool: DrawingTool = DrawingTool.PEN
)

private class JournalStorage(context: Context) {
    private val prefs = context.getSharedPreferences("journal_notes", Context.MODE_PRIVATE)

    fun save(date: LocalDate, strokes: List<Stroke>) {
        val array = JSONArray()
        strokes.forEach { stroke ->
            val obj = JSONObject()
            obj.put("width", stroke.width.toDouble())
            obj.put("color", stroke.color.value.toLong())
            obj.put("tool", stroke.tool.name)

            val points = JSONArray()
            stroke.points.forEach { p ->
                val point = JSONObject()
                point.put("x", p.x.toDouble())
                point.put("y", p.y.toDouble())
                points.put(point)
            }
            obj.put("points", points)
            array.put(obj)
        }
        prefs.edit().putString(date.toString(), array.toString()).apply()
    }

    fun load(date: LocalDate): List<Stroke> {
        val raw = prefs.getString(date.toString(), null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val pointsJson = obj.getJSONArray("points")
                    val points = buildList {
                        for (j in 0 until pointsJson.length()) {
                            val p = pointsJson.getJSONObject(j)
                            add(Offset(p.getDouble("x").toFloat(), p.getDouble("y").toFloat()))
                        }
                    }
                    add(
                        Stroke(
                            points = points,
                            width = obj.getDouble("width").toFloat(),
                            color = Color(obj.getLong("color").toULong()),
                            tool = DrawingTool.valueOf(obj.getString("tool"))
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

@Composable
fun JournalApp() {
    var selectedDate by remember { mutableStateOf(LocalDate.of(2026,1,1)) }
    var showIndex by remember { mutableStateOf(true) }

    MaterialTheme {
        if (showIndex) {
            IndexScreen(
                onDateSelected = { selectedDate = it; showIndex = false }
            )
        } else {
            DailyPage(
                date = selectedDate,
                onBack = { showIndex = true }
            )
        }
    }
}

@Composable
fun IndexScreen(onDateSelected: (LocalDate) -> Unit) {
    var year by remember { mutableStateOf(2026) }

    Scaffold(
        topBar = {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Daily Journal", fontSize = 28.sp)
                Row {
                    Button(onClick = { year = 2026 }) { Text("2026") }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { year = 2027 }) { Text("2027") }
                }
            }
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(20.dp)
        ) {
            Text("$year", fontSize = 32.sp)
            Spacer(Modifier.height(12.dp))

            val months = (1..12).toList()
            months.chunked(3).forEach { rowMonths ->
                Row(Modifier.fillMaxWidth()) {
                    rowMonths.forEach { month ->
                        MonthCard(
                            year = year,
                            month = month,
                            onDateSelected = onDateSelected,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun MonthCard(
    year: Int,
    month: Int,
    onDateSelected: (LocalDate) -> Unit,
    modifier: Modifier = Modifier
) {
    val first = LocalDate.of(year, month, 1)
    val days = first.lengthOfMonth()

    Card(
        modifier.padding(6.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(first.format(DateTimeFormatter.ofPattern("MMMM")), fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("M","T","W","T","F","S","S").forEach {
                    Text(it, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(4.dp))
            val offset = first.dayOfWeek.value - 1
            for (week in 0..5) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (col in 0..6) {
                        val n = week * 7 + col - offset + 1
                        if (n in 1..days) {
                            TextButton(
                                onClick = { onDateSelected(LocalDate.of(year, month, n)) },
                                contentPadding = PaddingValues(0.dp)
                            ) { Text("$n", fontSize = 11.sp) }
                        } else {
                            Spacer(Modifier.size(34.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DailyPage(date: LocalDate, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val storage = remember { JournalStorage(context) }
    val strokes = remember(date) {
        mutableStateListOf<Stroke>().apply { addAll(storage.load(date)) }
    }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var penWidth by remember { mutableFloatStateOf(4f) }
    var tool by remember { mutableStateOf(DrawingTool.PEN) }
    var selectedColor by remember { mutableStateOf(Color.Black) }

    val penColors = listOf(
        "Black" to Color.Black, "Blue" to Color(0xFF1565C0),
        "Red" to Color(0xFFD32F2F), "Green" to Color(0xFF2E7D32),
        "Purple" to Color(0xFF7B1FA2), "Orange" to Color(0xFFEF6C00),
        "Pink" to Color(0xFFC2185B), "Brown" to Color(0xFF6D4C41)
    )
    val highlighterColors = listOf(
        "Yellow" to Color(0xFFFFD600), "Green" to Color(0xFF76FF03),
        "Blue" to Color(0xFF40C4FF), "Pink" to Color(0xFFFF80AB),
        "Orange" to Color(0xFFFFAB40), "Purple" to Color(0xFFE040FB)
    )

    val quote = listOf(
        "Small steps every day lead to big results.",
        "Progress, not perfection.", "Make today meaningful.",
        "One day at a time.", "Stay focused. Stay positive.",
        "Every day is a fresh beginning."
    )[date.dayOfYear % 6]

    Scaffold(
        topBar = {
            Row(
                Modifier.fillMaxWidth().padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(onClick = onBack) { Text("← Index") }
                Text(
                    date.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy")),
                    fontSize = 20.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { if (strokes.isNotEmpty()) { strokes.removeAt(strokes.lastIndex); storage.save(date, strokes) } }) {
                        Text("Undo")
                    }
                    Button(onClick = { strokes.clear(); storage.save(date, strokes) }) { Text("Clear") }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 18.dp)) {
            Text("“$quote”", fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = tool == DrawingTool.PEN,
                    onClick = { tool = DrawingTool.PEN },
                    label = { Text("✎ Pen") }
                )
                FilterChip(
                    selected = tool == DrawingTool.HIGHLIGHTER,
                    onClick = { tool = DrawingTool.HIGHLIGHTER },
                    label = { Text("▰ Highlighter") }
                )
            }

            Spacer(Modifier.height(6.dp))

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                val palette = if (tool == DrawingTool.PEN) penColors else highlighterColors
                palette.forEach { (name, color) ->
                    Button(
                        onClick = { selectedColor = color },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = color,
                            contentColor = if (name in listOf("Yellow","Orange","Green"))
                                Color.Black else Color.White
                        )
                    ) { Text(name) }
                }
            }

            Spacer(Modifier.height(5.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (tool == DrawingTool.PEN) "Pen size" else "Highlight size")
                Slider(
                    value = penWidth,
                    onValueChange = { penWidth = it },
                    valueRange = if (tool == DrawingTool.PEN) 1f..12f else 8f..30f,
                    modifier = Modifier.width(190.dp)
                )
            }

            Spacer(Modifier.height(6.dp))

            Canvas(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White)
                    .border(1.dp, Color.LightGray)
                    .pointerInput(penWidth, selectedColor, tool) {
                        detectDragGestures(
                            onDragStart = { offset -> current = listOf(offset) },
                            onDrag = { change, _ -> current = current + change.position },
                            onDragEnd = {
                                if (current.isNotEmpty()) {
                                    strokes.add(Stroke(current, penWidth, selectedColor, tool))
                                    storage.save(date, strokes)
                                }
                                current = emptyList()
                            }
                        )
                    }
            ) {
                val lineGap = 42.dp.toPx()
                var y = 70.dp.toPx()
                while (y < size.height) {
                    drawLine(
                        Color(0xFFBDBDBD),
                        Offset(20.dp.toPx(), y),
                        Offset(size.width - 20.dp.toPx(), y),
                        strokeWidth = 1.dp.toPx()
                    )
                    y += lineGap
                }

                fun drawStroke(stroke: Stroke) {
                    val alpha = if (stroke.tool == DrawingTool.HIGHLIGHTER) 0.38f else 1f
                    stroke.points.zipWithNext().forEach { (a, b) ->
                        drawLine(
                            color = stroke.color.copy(alpha = alpha),
                            start = a, end = b,
                            strokeWidth = stroke.width,
                            cap = if (stroke.tool == DrawingTool.HIGHLIGHTER)
                                StrokeCap.Square else StrokeCap.Round
                        )
                    }
                }

                strokes.forEach { drawStroke(it) }
                drawStroke(Stroke(current, penWidth, selectedColor, tool))
            }
        }
    }
}
